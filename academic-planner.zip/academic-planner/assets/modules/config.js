// ══════════════════════════════════════════════════
//  config.js — 学业规划助手 全局配置文件
//  统一管理时间槽、颜色、映射等可调参数
// ══════════════════════════════════════════════════

var AppConfig = (function() {
  'use strict';

  // ── 标准教学节次（6个标准时段） ──
  var TIME_SLOTS = [
    { id: 1, label: '第一大节', time: '08:00-09:35', hours: 1.58 },
    { id: 2, label: '第二大节', time: '09:50-12:15', hours: 2.42 },
    { id: 3, label: '第三大节', time: '13:30-15:05', hours: 1.58 },
    { id: 4, label: '第四大节', time: '15:20-16:55', hours: 1.58 },
    { id: 5, label: '第五大节', time: '17:05-18:40', hours: 1.58 },
    { id: 6, label: '第六大节', time: '19:20-21:45', hours: 2.42 }
  ];

  // ── 仪表盘/周视图共同使用的 5 节次（排除第5节） ──
  var DISPLAY_SLOTS = TIME_SLOTS.filter(function(s) { return s.id !== 5; });

  // 时间槽快速查询映射
  var SLOT_HOURS_MAP = {};
  TIME_SLOTS.forEach(function(s) { SLOT_HOURS_MAP[s.time] = s.hours; });

  // ── 星期映射 ──
  var WEEKDAY_MAP = {
    0: '周日', 1: '周一', 2: '周二', 3: '周三',
    4: '周四', 5: '周五', 6: '周六'
  };
  var WEEKDAY_NAMES = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  var DISPLAY_ORDER = [1, 2, 3, 4, 5, 6, 0]; // 表头顺序：周一~周日

  // ── 类型标签 ──
  var TYPE_LABELS = {
    'class': '课程',
    'task': '自习',
    'activity': '活动'
  };

  // ── 颜色主题（保持与原版一致） ──
  var COLORS = {
    primary: '#667eea',
    secondary: '#764ba2',
    gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',

    classBg: '#e8f4fd',
    classText: '#1976d2',
    taskBg: '#fef3e2',
    taskText: '#e65100',
    activityBg: '#e8f5e9',
    activityText: '#2e7d32',

    bg: '#f5f6fa',
    cardBg: 'rgba(255,255,255,.95)',
    textPrimary: '#333',
    textSecondary: '#888',
    textMuted: '#999',
    border: '#eee',
    urgentRed: '#e53935',
    warningOrange: '#fb8c00'
  };

  // ── 时段建议规则 ──
  function getTimeSuggestion(hour, minute, weekday) {
    var t = hour * 60 + minute;
    if (weekday === 6 || weekday === 0) {
      return '周末 🏖 好好休息，或者把没做完的补上';
    }
    if (t >= 480 && t < 570)  return '第一节上课时间 — 专注听课 📖';
    if (t >= 590 && t < 735)  return '第二节上课/自习时间 — 认真学 📝';
    if (t >= 735 && t < 810)  return '午间休息 — 吃饭+午休 🍚';
    if (t >= 810 && t < 905)  return '第三节课 — 集中精力 📘';
    if (t >= 920 && t < 1015) return '第四节课 — 最后冲刺 💪';
    if (t >= 1025 && t < 1120) return '第五节课 — 坚持住 🏃';
    if (t >= 1120 && t < 1305) return '晚间休息/晚餐时间 🍜';
    if (t >= 1305) return '晚间学习 — 复习+预习 🌙';
    return '还没到上课时间，准备一下今天的计划吧 📋';
  }

  // ── 公开接口 ──
  return {
    TIME_SLOTS: TIME_SLOTS,
    DISPLAY_SLOTS: DISPLAY_SLOTS,
    SLOT_HOURS_MAP: SLOT_HOURS_MAP,
    WEEKDAY_MAP: WEEKDAY_MAP,
    WEEKDAY_NAMES: WEEKDAY_NAMES,
    DISPLAY_ORDER: DISPLAY_ORDER,
    TYPE_LABELS: TYPE_LABELS,
    COLORS: COLORS,
    getTimeSuggestion: getTimeSuggestion
  };
})();
