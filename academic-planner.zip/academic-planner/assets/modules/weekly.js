// ══════════════════════════════════════════════════
//  weekly.js — 周视图渲染模块
//  生成 5×7 教学周课表 + ISO 周号标题
// ══════════════════════════════════════════════════

var WeeklyView = (function() {
  'use strict';

  var util = RenderUtil;
  var cfg = AppConfig;
  var sched = Schedule;

  /**
   * 初始化周视图
   * @param {Object} elMap - { weeklyTable, weekLabel }
   */
  function init(elMap) {
    renderWeekLabel(elMap.weekLabel);
    renderTable(elMap.weeklyTable);
  }

  // ── 标题：ISO周号 + 日期范围 ──
  function renderWeekLabel(el) {
    if (!el) return;
    var now = new Date();
    var iso = util.getISOWeekNumber(now);
    var range = util.getWeekDateRange(now);
    el.innerHTML = [
      iso.year, '年 第<strong>', iso.week, '</strong>周',
      ' &nbsp;|&nbsp; ', range
    ].join('');
  }

  // ── 生成完整课表 ──
  function renderTable(el) {
    if (!el) return;

    var today = new Date().getDay();
    var order = cfg.DISPLAY_ORDER;
    var names = cfg.WEEKDAY_NAMES;
    var slots = cfg.DISPLAY_SLOTS;
    var todayIdx = order.indexOf(today);

    // 表头
    var headerCells = order.map(function(d, i) {
      var cls = i === todayIdx ? ' class="today"' : '';
      return '<th' + cls + '>' + names[d] + '</th>';
    });

    var thead = [
      '<thead><tr>',
        '<th>节次</th>',
        headerCells.join(''),
      '</tr></thead>'
    ];

    // 表体
    var rows = slots.map(function(slot) {
      var cells = order.map(function(dayNum) {
        var courses = sched.getDayCourses(dayNum);
        var match = null;
        if (courses) {
          for (var i = 0; i < courses.length; i++) {
            if (courses[i].t === slot.time) {
              match = courses[i];
              break;
            }
          }
        }
        if (!match) return '<td class="empty-cell">—</td>';

        var cls = util.getBadgeClass(match.type);
        var label = util.getTypeLabel(match.type);
        var isToday = dayNum === today ? ' class="today"' : '';
        var locHtml = match.loc ? '<span class="loc">' + esc(match.loc) + '</span>' : '';

        return [
          '<td' + isToday + '>',
            '<span class="class-badge ' + cls + '">', esc(match.n), locHtml, '</span>',
            '<br><span class="type-sub">', label, '</span>',
          '</td>'
        ].join('');
      });

      return [
        '<tr>',
          '<td class="time-cell"><b>', slot.label, '</b><small>', slot.time, '</small></td>',
          cells.join(''),
        '</tr>'
      ].join('');
    });

    el.innerHTML = thead.join('') + '<tbody>' + rows.join('') + '</tbody>';
  }

  function esc(s) {
    if (!s) return '';
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  return { init: init };
})();
