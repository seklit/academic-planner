// ══════════════════════════════════════════════════
//  render.js — 通用渲染辅助模块
//  为 dashboard 和 weekly 提供共享的 DOM 和格式化工具
// ══════════════════════════════════════════════════

var RenderUtil = (function() {
  'use strict';

  var cfg = AppConfig;

  /**
   * 数字补零
   */
  function pad(n) {
    return n < 10 ? '0' + n : String(n);
  }

  /**
   * 格式化当前时间 HH:MM:SS
   */
  function formatTime(d) {
    d = d || new Date();
    return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }

  /**
   * 格式化日期字符串 "YYYY年M月D日 周X"
   */
  function formatDate(d) {
    d = d || new Date();
    return d.getFullYear() + '年' + (d.getMonth() + 1) + '月' + d.getDate() + '日 ' + cfg.WEEKDAY_NAMES[d.getDay()];
  }

  /**
   * 格式化日期范围（周一~周日）
   */
  function getWeekDateRange(baseDate) {
    var d = baseDate || new Date();
    var day = d.getDay();
    var diff = day === 0 ? -6 : 1 - day;
    var monday = new Date(d);
    monday.setDate(d.getDate() + diff);
    var sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    function fmt(dd) { return (dd.getMonth() + 1) + '/' + dd.getDate(); }
    return fmt(monday) + ' (周一) — ' + fmt(sunday) + ' (周日)';
  }

  /**
   * 计算 ISO 周号
   */
  function getISOWeekNumber(d) {
    d = d || new Date();
    var temp = new Date(d);
    temp.setDate(temp.getDate() + 3);
    var year = temp.getFullYear();
    var firstThu = new Date(year, 0, 4);
    var weekNum = 1 + Math.round(((temp - firstThu) / 86400000 - 3 + (firstThu.getDay() + 6) % 7) / 7);
    return { year: d.getFullYear(), week: weekNum };
  }

  /**
   * 生成课程条目的 CSS 类名
   */
  function getTypeClass(type) {
    var map = {
      'class': 'type-class',
      'task': 'type-task',
      'activity': 'type-activity'
    };
    return map[type] || 'type-task';
  }

  /**
   * 生成课程徽章的 CSS 类名（周视图）
   */
  function getBadgeClass(type) {
    var map = {
      'class': 'bg-class',
      'task': 'bg-task',
      'activity': 'bg-activity'
    };
    return map[type] || 'bg-task';
  }

  /**
   * 获取类型的中文标签
   */
  function getTypeLabel(type) {
    return cfg.TYPE_LABELS[type] || type;
  }

  /**
   * 根据紧急度获取指示器样式
   */
  function getUrgencyStyle(urgent) {
    return {
      background: urgent ? cfg.COLORS.urgentRed : cfg.COLORS.warningOrange
    };
  }

  /**
   * 获取紧急指示图标
   */
  function getUrgencyIcon(urgent) {
    return urgent ? '🔴' : '🟡';
  }

  // ── 公开接口 ──
  return {
    pad: pad,
    formatTime: formatTime,
    formatDate: formatDate,
    getWeekDateRange: getWeekDateRange,
    getISOWeekNumber: getISOWeekNumber,
    getTypeClass: getTypeClass,
    getBadgeClass: getBadgeClass,
    getTypeLabel: getTypeLabel,
    getUrgencyStyle: getUrgencyStyle,
    getUrgencyIcon: getUrgencyIcon
  };
})();
