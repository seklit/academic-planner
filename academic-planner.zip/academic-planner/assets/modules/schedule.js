// ══════════════════════════════════════════════════
//  schedule.js — 课表数据查询模块
//  提供对 SCHEDULE_DATA 的只读查询接口
//  不修改数据，仅封装查询逻辑
// ══════════════════════════════════════════════════

var Schedule = (function() {
  'use strict';

  var cfg = AppConfig;

  /**
   * 获取今日课程列表
   * @returns {Array} [{t, n, type, loc?}, ...]
   */
  function getTodayCourses() {
    var today = new Date().getDay();
    var data = getData();
    var courses = data.courses[today];
    return courses || [];
  }

  /**
   * 获取指定日的课程
   * @param {number} dayNum - 0=周日 ... 6=周六
   */
  function getDayCourses(dayNum) {
    var data = getData();
    return data.courses[dayNum] || [];
  }

  /**
   * 获取未完成的 DDL
   * @returns {Array} [{name, ddl, days, urgent}, ...]
   */
  function getPendingAssignments() {
    var data = getData();
    return (data.assignments || []).filter(function(a) { return !a.done; });
  }

  /**
   * 获取已完成 DDL
   */
  function getDoneAssignments() {
    var data = getData();
    return (data.assignments || []).filter(function(a) { return a.done; });
  }

  /**
   * 按紧急度排序的 DDL
   */
  function getSortedAssignments() {
    return getPendingAssignments().sort(function(a, b) {
      if (a.urgent !== b.urgent) return a.urgent ? -1 : 1;
      return a.days - b.days;
    });
  }

  /**
   * 获取统计信息
   */
  function getStats() {
    var data = getData();
    return data.stats || { courseHours: 0, pendingCount: 0, freeHours: 0, fitnessDays: 0 };
  }

  /**
   * 获取周范围描述
   */
  function getWeekRange() {
    var data = getData();
    return data.weekRange || '';
  }

  /**
   * 安全获取数据
   */
  function getData() {
    return (typeof SCHEDULE_DATA !== 'undefined')
      ? SCHEDULE_DATA
      : { courses: {}, assignments: [], stats: { courseHours: 0, pendingCount: 0, freeHours: 0, fitnessDays: 0 }, weekRange: '' };
  }

  /**
   * 按时间槽索引排序课程
   */
  function sortByTime(courses) {
    if (!courses) return [];
    var timeOrder = {};
    cfg.DISPLAY_SLOTS.forEach(function(s, i) { timeOrder[s.time] = i; });
    return courses.slice().sort(function(a, b) {
      return (timeOrder[a.t] || 99) - (timeOrder[b.t] || 99);
    });
  }

  /**
   * 获取课程数量统计
   */
  function getCourseCount() {
    var data = getData();
    var count = 0;
    Object.keys(data.courses).forEach(function(day) {
      (data.courses[day] || []).forEach(function(c) {
        if (c.type === 'class') count++;
      });
    });
    return count;
  }

  /**
   * 计算自由时间（task 类型 × 2h）
   */
  function calcFreeHours() {
    var data = getData();
    var freeSlots = 0;
    Object.keys(data.courses).forEach(function(day) {
      (data.courses[day] || []).forEach(function(c) {
        if (c.type === 'task') freeSlots++;
      });
    });
    return freeSlots * 2;
  }

  // ── 公开接口 ──
  return {
    getTodayCourses: getTodayCourses,
    getDayCourses: getDayCourses,
    getPendingAssignments: getPendingAssignments,
    getDoneAssignments: getDoneAssignments,
    getSortedAssignments: getSortedAssignments,
    getStats: getStats,
    getWeekRange: getWeekRange,
    sortByTime: sortByTime,
    getCourseCount: getCourseCount,
    calcFreeHours: calcFreeHours
  };
})();
