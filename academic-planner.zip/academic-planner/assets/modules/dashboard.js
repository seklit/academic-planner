// ══════════════════════════════════════════════════
//  dashboard.js — 学业仪表盘核心渲染模块
//  负责首页时钟、今日课表、DDL 列表、统计面板
// ══════════════════════════════════════════════════

var Dashboard = (function() {
  'use strict';

  var util = RenderUtil;
  var cfg = AppConfig;
  var sched = Schedule;

  // ═══ 私有引用（初始化时注入） ═══
  var _els = {};

  /**
   * 初始化：绑定 DOM 元素并开始渲染
   * @param {Object} elMap - { clockDisplay, dateDisplay, nowSuggestion, todaySchedule, ddlList, courseHours, pendingCount, freeHours, fitnessDays }
   */
  function init(elMap) {
    _els = elMap;
    startClock();
    startSuggestion();
    render();
  }

  // ── 时钟 ──
  var _clockTimer = null;
  function startClock() {
    if (_clockTimer) clearInterval(_clockTimer);
    function tick() {
      if (_els.clockDisplay) _els.clockDisplay.textContent = util.formatTime();
      if (_els.dateDisplay) _els.dateDisplay.textContent = util.formatDate();
    }
    tick();
    _clockTimer = setInterval(tick, 1000);
  }

  // ── 时段建议 ──
  var _suggTimer = null;
  function startSuggestion() {
    if (_suggTimer) clearInterval(_suggTimer);
    function update() {
      if (_els.nowSuggestion) {
        var d = new Date();
        _els.nowSuggestion.textContent = cfg.getTimeSuggestion(d.getHours(), d.getMinutes(), d.getDay());
      }
    }
    update();
    _suggTimer = setInterval(update, 60000);
  }

  // ── 主渲染 ──
  function render() {
    renderTodaySchedule();
    renderDDL();
    renderStats();
  }

  /**
   * 渲染今日课表
   */
  function renderTodaySchedule() {
    var el = _els.todaySchedule;
    if (!el) return;

    var courses = sched.getTodayCourses();
    if (!courses || courses.length === 0) {
      el.innerHTML = '<p class="empty-hint">今天没有安排 🎉</p>';
      return;
    }

    var sorted = sched.sortByTime(courses);
    el.innerHTML = sorted.map(function(c) {
      return [
        '<div class="course-item">',
          '<span class="course-time">', escapeHTML(c.t), '</span>',
          '<span class="course-name">', escapeHTML(c.n), '</span>',
          '<span class="course-type ', util.getTypeClass(c.type), '">',
            util.getTypeLabel(c.type),
          '</span>',
        '</div>'
      ].join('');
    }).join('');
  }

  /**
   * 渲染 DDL 列表
   */
  function renderDDL() {
    var el = _els.ddlList;
    if (!el) return;

    var items = sched.getSortedAssignments();
    if (!items || items.length === 0) {
      el.innerHTML = '<p class="empty-hint">暂无待办 ✅</p>';
      return;
    }

    el.innerHTML = items.map(function(a) {
      var icon = util.getUrgencyIcon(a.urgent);
      var style = util.getUrgencyStyle(a.urgent);
      return [
        '<div class="assign-item">',
          '<span class="assign-urgent" style="background:', style.background, '"></span>',
          '<span class="', (a.done ? 'assign-done' : ''), '">',
            icon, ' ', escapeHTML(a.name),
          '</span>',
          '<span class="assign-ddl">', escapeHTML(a.ddl || ''), '</span>',
        '</div>'
      ].join('');
    }).join('');
  }

  /**
   * 渲染统计面板
   */
  function renderStats() {
    var stats = sched.getStats();
    setText(_els.courseHours, stats.courseHours);
    setText(_els.pendingCount, stats.pendingCount);
    setText(_els.freeHours, stats.freeHours);
    setText(_els.fitnessDays, stats.fitnessDays);
  }

  // ── 辅助 ──
  function setText(el, value) {
    if (el) el.textContent = (value !== undefined && value !== null) ? value : '-';
  }

  function escapeHTML(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  // ── 公开接口 ──
  return {
    init: init,
    render: render,
    renderTodaySchedule: renderTodaySchedule,
    renderDDL: renderDDL,
    renderStats: renderStats
  };
})();
