# 📚 学业规划助手

封装的学业规划工具，提供**仪表盘**、**周视图**、**数据同步**三大核心功能。

---

## 快速开始

1. 用浏览器打开 `index.html` 查看仪表盘
2. 在 `data/data.js` 中填写你的课表和 DDL
3. 刷新页面，数据自动更新

> 或者：在对话中说「添加课表」「新DDL」，AI 帮你自动修改 `data/data.js`

---

## 项目结构

```
├── index.html              # 学业仪表盘（今日课表 + DDL + 统计）
├── weekly.html             # 周视图表格
├── modules/                # 模块化代码
│   ├── config.js           # 全局配置（时间槽、颜色、映射）
│   ├── schedule.js         # 数据查询模块
│   ├── render.js           # 通用渲染工具
│   ├── dashboard.js        # 仪表盘渲染模块
│   ├── weekly.js           # 周视图渲染模块
│   └── styles.css          # 全局样式表
├── data/                   # 数据层（你只需要改这个目录）
│   ├── data.js             # 仪表盘数据（课表 + 作业 + 统计）
│   ├── timetable.md        # 课表 Markdown（可选，配合 sync-data.py）
│   └── assignments.md      # 作业池 Markdown（可选，配合 sync-data.py）
├── tools/                  # 命令行工具
│   ├── sync-data.py        # Markdown → data.js 同步器
│   └── notify.py           # 微信推送（需配置 Server酱）
└── README.md               # 本文件
```

---

## 数据格式

### data.js 结构

```javascript
var SCHEDULE_DATA = {
  "courses": {
    "1": [   // 0=周日, 1=周一...6=周六
      {"t":"09:50-12:15","n":"高等数学","type":"class","loc":"一教101"},
      {"t":"13:30-15:05","n":"图书馆自习","type":"task"}
    ]
  },
  "assignments": [
    {"name":"数学作业","ddl":"5/20(周三)","days":6,"urgent":true,"done":false}
  ],
  "stats": {
    "courseHours": 13,
    "pendingCount": 3,
    "freeHours": 22,
    "fitnessDays": 3
  },
  "weekRange": "5月12日~5月18日"
};
```

### 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `courses` | Object | 键为星期数字（0=周日, 1=周一...），值为课程/活动数组 |
| `courses[].t` | String | 时间范围，如 `"09:50-12:15"` |
| `courses[].n` | String | 名称 |
| `courses[].type` | String | `"class"`（课程）、`"task"`（自习/任务）、`"activity"`（活动） |
| `courses[].loc` | String | 可选，上课地点 |
| `assignments[].name` | String | 任务名称 |
| `assignments[].ddl` | String | 截止日期，如 `"5/20(周三)"` |
| `assignments[].days` | Number | 剩余天数 |
| `assignments[].urgent` | Boolean | 是否紧急（7天内为 true） |
| `assignments[].done` | Boolean | 是否已完成 |

### 标准时间槽

| 节次 | 时间 |
|------|------|
| 第一大节 | 08:00-09:35 |
| 第二大节 | 09:50-12:15 |
| 第三大节 | 13:30-15:05 |
| 第四大节 | 15:20-16:55 |
| 第五大节 | 17:05-18:40 |
| 第六大节 | 19:20-21:45 |

---

## 工作流：Markdown → 仪表盘

如果你更喜欢用 Markdown 管理课表和 DDL：

1. 编辑 `data/timetable.md` 和 `data/assignments.md`
2. 运行同步脚本：
   ```bash
   python tools/sync-data.py
   ```
3. 刷新 `index.html`，数据自动更新

### timetable.md 格式

参照 `data/timetable.md` 中的表结构，按时间槽和星期填写。

### assignments.md 格式

参照 `data/assignments.md` 中的三区（紧急/即将来临/较远）表格。

---

## 微信推送

`tools/notify.py` 支持 4 种推送模式：

| 模式 | 命令 | 建议时间 |
|------|------|----------|
| 早安课程提醒 | `python tools/notify.py morning` | 07:30 |
| DDL 紧急检查 | `python tools/notify.py ddl` | 19:00 |
| 健身督促 | `python tools/notify.py fitness` | 21:00 |
| 晚安总结 | `python tools/notify.py night` | 22:30 |

使用前请将 `tools/notify.py` 中的 `SENDKEY` 替换为你的 [Server酱](https://sct.ftqq.com/) SendKey。

---

## 模块化设计

所有功能模块独立，可单独复用：

| 模块 | 职责 | 依赖 |
|------|------|------|
| `config.js` | 全局配置（时间槽、颜色、映射） | 无 |
| `schedule.js` | 数据查询接口 | `config.js`, `data.js` |
| `render.js` | 通用格式化工具 | `config.js` |
| `dashboard.js` | 仪表盘渲染 | `config.js`, `schedule.js`, `render.js` |
| `weekly.js` | 周视图渲染 | `config.js`, `schedule.js`, `render.js` |

### 如何复用

如果你想在自己的页面中使用课表数据：

```html
<script src="modules/config.js"></script>
<script src="data/data.js"></script>
<script src="modules/schedule.js"></script>
<script>
  // 获取今日课程
  var today = Schedule.getTodayCourses();
  // 获取所有未完成 DDL
  var ddl = Schedule.getSortedAssignments();
  // 获取统计
  var stats = Schedule.getStats();
</script>
```
