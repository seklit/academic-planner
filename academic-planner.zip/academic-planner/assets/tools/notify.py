"""
微信推送工具 — 阅读 data/*.md 生成提醒消息
通过 Server酱 推送到微信（需要配置 SENDKEY）

用法: python tools/notify.py [morning|fitness|ddl|night]

配置：请将下方 SENDKEY 替换为你的 Server酱 SendKey
      获取地址：https://sct.ftqq.com/
"""
import json
import os
import sys
import urllib.parse
import urllib.request
import re
from datetime import datetime

# ── 配置区域 ──
# TODO: 替换为你的 Server酱 SendKey
SENDKEY = "YOUR_SENDKEY_HERE"

# ── 路径 ──
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, '..', 'data')

def read_file(name):
    path = os.path.join(DATA_DIR, name)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    return ""

def push(title, body):
    data = urllib.parse.urlencode({"title": title, "desp": body}).encode()
    req = urllib.request.Request(
        f"https://sctapi.ftqq.com/{SENDKEY}.send", data=data
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())

def today_str():
    return datetime.now().strftime("%Y-%m-%d")

def get_weekday():
    return ["周一", "周二", "周三", "周四", "周五", "周六", "周日"][
        datetime.now().weekday()
    ]

def morning_check():
    """早安推送"""
    timetable = read_file("timetable.md")
    assignments = read_file("assignments.md")
    wd = get_weekday()

    # 提取今天课程
    courses_today = []
    lines = timetable.split("\n")
    in_table = False
    wd_col = -1
    for line in lines:
        if "| 时间 |" in line:
            cols = [c.strip() for c in line.split("|")]
            for i, c in enumerate(cols):
                if wd in c:
                    wd_col = i
            in_table = True
            continue
        if in_table and wd_col > 0 and line.strip().startswith("|"):
            cols = [c.strip() for c in line.split("|")]
            if len(cols) > wd_col:
                cell = cols[wd_col]
                if cell and all(k not in cell for k in ["空闲", "自由", "🍚", "课间", "🌙", "🌅"]) and cell.strip():
                    courses_today.append(cell)

    # 从作业池查紧急DDL
    urgent_ddls = []
    today_md = today_str()[5:].replace("-", "/")
    for line in assignments.split("\n"):
        if today_md in line:
            line_clean = re.sub(r"[|📝💻🎤]", " ", line).strip()
            if line_clean and any(s in line_clean for s in ["论文", "OOP", "Pre", "初稿", "作业"]):
                urgent_ddls.append(line_clean[:60])

    if courses_today:
        course_str = "、".join(courses_today[:4])
        title = f"同志们，今天有课！"
        body = f"同志，早上好！\n\n今天是{wd}，我们的课程有：{course_str}\n\n好好学习，天天向上！\n"
    else:
        title = f"同志们，今天自由安排！"
        body = f"同志，早上好！\n\n今天是{wd}，没有课程安排。\n\n自由时间更要抓紧！\n"

    if urgent_ddls:
        body += f"\n📢 注意！以下任务战斗到了紧要关头：\n"
        for d in urgent_ddls[:3]:
            body += f"  • {d.strip()}\n"

    body += f"\n---\n📅 {today_str()} | 学业助手"
    return push(title, body)

def fitness_check():
    """健身督促"""
    wd = get_weekday()
    if wd not in ["周一", "周三", "周四"]:
        return None
    title = "锻炼时间到了！"
    body = f"今天是{wd}，该锻炼了！身体是革命的本钱。\n\n---\n📅 {today_str()} | 学业助手"
    return push(title, body)

def ddl_check():
    """DDL 紧急警告"""
    assignments = read_file("assignments.md")
    today_md = today_str()[5:].replace("-", "/")
    urgent = []
    for line in assignments.split("\n"):
        if today_md in line:
            text = line.lower()
            if any(s in text for s in ["论文", "oop", "pre", "作业", "提交"]):
                urgent.append(line.strip()[:60])
    if not urgent:
        return None
    title = "紧急！DDL 到期！"
    body = "以下任务已到最终期限：\n"
    for u in urgent[:3]:
        body += f"  • {u}\n"
    body += f"\n抓紧时间，立即完成！\n\n---\n📅 {today_str()} | 学业助手"
    return push(title, body)

def night_check():
    """晚安推送"""
    wd = get_weekday()
    title = "今天的战斗结束了"
    body = f"同志，{wd}即将过去。\n\n回顾今天的成果：\n"
    body += "  • 课程是否认真学习了？\n"
    body += "  • 作业是否按时完成了？\n"
    body += "  • 有没有坚持锻炼？\n\n"
    body += "好好休息，明天继续！晚安。\n\n---\n📅 {today_str()} | 学业助手"
    return push(title, body)


if __name__ == "__main__":
    if SENDKEY == "YOUR_SENDKEY_HERE":
        print("⚠️  请先在 tools/notify.py 中配置 SENDKEY（Server酱 SendKey）")
        print("    获取地址：https://sct.ftqq.com/")
        sys.exit(1)

    cmd = sys.argv[1] if len(sys.argv) > 1 else "morning"
    actions = {"morning": morning_check, "fitness": fitness_check, "ddl": ddl_check, "night": night_check}

    if cmd in actions:
        result = actions[cmd]()
        if result:
            print(f"✅ 推送成功: {result.get('data', {}).get('pushid', '?')} - {cmd}")
        else:
            print(f"⏭️  跳过: {cmd}（不需要推送）")
    else:
        print(f"用法: python tools/notify.py [morning|fitness|ddl|night]")
