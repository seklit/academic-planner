"""
数据同步器 — 读 data/*.md → 生成 data/data.js
AI 修改 data/ 下的 .md 文件后运行此脚本，仪表盘 + 周视图自动刷新

用法: python tools/sync-data.py

数据流:
  data/timetable.md    → 课程表 (courses)
  data/assignments.md  → 作业/DDL (assignments)
                       → 统计 (stats)
                       → data/data.js
"""
import re, os, json
from datetime import datetime

# 相对于 tools/ 的 data 目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, '..', 'data')

def read(fname):
    path = os.path.join(DATA_DIR, fname)
    return open(path, encoding='utf-8').read() if os.path.exists(path) else ''

def write(fname, content):
    path = os.path.join(DATA_DIR, fname)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)

# ── 标准时间槽（5个，排除第5节17:05-18:40） ──
TIME_SLOTS = [
    '08:00-09:35',
    '09:50-12:15',
    '13:30-15:05',
    '15:20-16:55',
    '19:20-21:45',
]

# 星期映射
WD_MAP = {'周一': 1, '周二': 2, '周三': 3, '周四': 4, '周五': 5, '周六': 6, '周日': 0}

# 简称→全称映射（可根据需要扩展）
NAME_MAP = {
    '高微': '高等微积分(2)',
    '大物B': '大学物理B(1)',
    'OOP': '面向对象程序设计基础(OOP)',
    'AI导引': '人工智能导引',
    '高微习题课': '高等微积分习题课',
    '概率论': '概率论',
    '近现代史纲要': '中国近现代史纲要',
    '体育': '体育(2)',
    '写作与沟通': '写作与沟通',
    '英语听说(A)': '英语听说交流(A)',
    '人工智能与自主学习': '人工智能与自主学习',
}

# ── 周末固定活动（可修改） ──
WEEKEND_DEFAULTS = {
    6: [
        {'t': '08:00-09:35', 'n': '自由安排', 'type': 'task'},
        {'t': '09:50-12:15', 'n': '自由安排', 'type': 'task'},
        {'t': '13:30-15:05', 'n': '自由安排', 'type': 'task'},
        {'t': '15:20-16:55', 'n': '参观/活动', 'type': 'activity'},
        {'t': '19:20-21:45', 'n': '健身/自由', 'type': 'task'},
    ],
    0: [
        {'t': '08:00-09:35', 'n': '自由安排', 'type': 'task'},
        {'t': '09:50-12:15', 'n': '自由安排', 'type': 'task'},
        {'t': '13:30-15:05', 'n': '黄金2h冲刺', 'type': 'task'},
        {'t': '15:20-16:55', 'n': '自由活动', 'type': 'activity'},
        {'t': '19:20-21:45', 'n': '下周规划', 'type': 'task'},
    ],
}


# ══════════════════════════════════════════
#  课表解析
# ══════════════════════════════════════════

def parse_timetable(text):
    """解析 timetable.md 主课表，返回 {day_num: [{t, n, type, loc?}]}"""
    courses = {}
    lines = text.split('\n')
    in_table = False
    headers = []
    data_lines = []

    for line in lines:
        stripped = line.strip()
        if stripped.startswith('| 时间') and '|' in stripped:
            in_table = True
            parts = [p.strip() for p in stripped.split('|')]
            headers = parts[1:-1]
            continue
        if in_table and stripped.startswith('| **') and '|' in stripped:
            data_lines.append(stripped)
        if in_table and not stripped.startswith('|') and stripped:
            in_table = False

    for line in data_lines:
        parts = [p.strip() for p in line.split('|')]
        parts = parts[1:-1]
        if len(parts) < 2:
            continue

        time_match = re.search(r'\*\*(\d{2}:\d{2}-\d{2}:\d{2})\*\*', parts[0])
        if not time_match:
            continue
        time_slot = time_match.group(1)
        if time_slot not in TIME_SLOTS:
            continue

        for col_idx, cell in enumerate(parts[1:], start=1):
            if col_idx >= len(headers):
                break
            wd_name = headers[col_idx].strip()
            if wd_name not in WD_MAP:
                continue
            day_num = WD_MAP[wd_name]

            cell = cell.strip()
            if cell in ('—', '— ', '空闲', '空闲 '):
                continue

            items = re.split(r'\s*\+\s*', cell)
            for item in items:
                item = item.strip()
                if not item or item in ('—', '空闲'):
                    continue
                entry = _parse_cell(item, time_slot)
                if entry:
                    courses.setdefault(day_num, []).append(entry)

    return courses


def _parse_cell(cell, time_slot):
    """解析单个单元格 → {t, n, type, loc?}"""
    cell = re.sub(r'^✅\s*', '', cell).strip()

    # 带地点: **高微**(教师；地点)
    m = re.match(r'\*\*(.+?)\*\*\((.+?)[；;](.+?)\)$', cell)
    if m:
        short_name = m.group(1).strip()
        loc = m.group(3).strip()
        full_name = NAME_MAP.get(short_name, short_name)
        return {'t': time_slot, 'n': full_name, 'type': 'class', 'loc': loc}

    # 不带地点: **课程名**(教师)
    m = re.match(r'\*\*(.+?)\*\*\((.+?)\)$', cell)
    if m:
        short_name = m.group(1).strip()
        full_name = NAME_MAP.get(short_name, short_name)
        return {'t': time_slot, 'n': full_name, 'type': 'class'}

    # 纯名称: **课程名**
    m = re.match(r'\*\*(.+?)\*\*$', cell)
    if m:
        raw_name = m.group(1).strip()
        full_name = NAME_MAP.get(raw_name, raw_name)
        return {'t': time_slot, 'n': full_name, 'type': 'class'}

    # 图书馆/自习
    if '图书馆' in cell or '自习' in cell:
        return {'t': time_slot, 'n': '图书馆自习', 'type': 'task'}

    return {'t': time_slot, 'n': cell.strip(), 'type': 'task'}


# ══════════════════════════════════════════
#  作业/DDL 解析
# ══════════════════════════════════════════

def parse_assignments(text):
    """解析 assignments.md → [{name, ddl, days, urgent, done}]"""
    assignments = []
    lines = text.split('\n')
    in_section = False

    for line in lines:
        stripped = line.strip()
        if '| 任务 |' in stripped and '|' in stripped:
            in_section = True
            continue
        if in_section and stripped.startswith('|') and ('| 日期 |' in stripped or '|---' in stripped):
            continue
        if in_section and stripped.startswith('|') and '---' not in stripped:
            parts = [p.strip() for p in stripped.split('|')]
            parts = [p for p in parts if p]
            if len(parts) < 5:
                in_section = False
                continue
            name = parts[0]
            ddl = parts[3] if len(parts) > 3 else ''
            name = re.sub(r'[🎉📝🎊✅⏳📅🔖]', '', name).strip()
            if not name or name in ('—', '— ') or '新课作业待确认' in name:
                continue
            status_col = parts[5] if len(parts) > 5 else ''
            done = '✅' in status_col or '已完成' in status_col
            urgent, days = _calc_urgency(ddl)
            assignments.append({
                'name': name, 'ddl': ddl, 'days': days,
                'urgent': urgent, 'done': done,
            })
        elif in_section and not stripped.startswith('|'):
            in_section = False

    # 事件日历表
    in_cal = False
    for line in lines:
        stripped = line.strip()
        if '| 日期 | 事件 |' in stripped:
            in_cal = True
            continue
        if in_cal and stripped.startswith('|') and '---' not in stripped:
            parts = [p.strip() for p in stripped.split('|')]
            parts = [p for p in parts if p]
            if len(parts) < 3:
                continue
            date_str = re.sub(r'\*\*', '', parts[0]).strip()
            event = re.sub(r'[✅📅🎉🎊🔖\*]', '', parts[1]).strip()
            if event in ('事件', '—', '— '):
                continue
            type_col = parts[2] if len(parts) > 2 else ''
            done = '已完成' in type_col or '已结束' in type_col
            if any(a['name'] == event for a in assignments):
                continue
            urgent, days = _calc_urgency(date_str)
            assignments.append({
                'name': event, 'ddl': date_str, 'days': days,
                'urgent': urgent, 'done': done,
            })

    return assignments


def _calc_urgency(ddl_str):
    if not ddl_str or ddl_str == '待定':
        return False, 30
    date_m = re.search(r'(\d{1,2})/(\d{1,2})', ddl_str)
    if not date_m:
        return False, 30
    month, day = int(date_m.group(1)), int(date_m.group(2))
    today = datetime.now()
    try:
        target = datetime(today.year, month, day)
        days = (target - today).days
        return days <= 7, max(days, 0)
    except ValueError:
        return False, 30


# ══════════════════════════════════════════
#  统计计算
# ══════════════════════════════════════════

def calc_stats(courses, assignments):
    SLOT_HOURS = {
        '08:00-09:35': 1.58, '09:50-12:15': 2.42,
        '13:30-15:05': 1.58, '15:20-16:55': 1.58,
        '19:20-21:45': 2.42,
    }
    course_hours = 0
    for day_courses in courses.values():
        for c in day_courses:
            if c['type'] == 'class':
                course_hours += SLOT_HOURS.get(c['t'], 1.5)

    pending = len([a for a in assignments if not a.get('done')])

    free_slots = 0
    for day_courses in courses.values():
        for c in day_courses:
            if c['type'] == 'task':
                free_slots += 1

    return {
        'courseHours': round(course_hours),
        'pendingCount': pending,
        'freeHours': free_slots * 2,
        'fitnessDays': 3,
    }


# ══════════════════════════════════════════
#  主流程
# ══════════════════════════════════════════

def gen():
    timetable = read('timetable.md')
    ass_text = read('assignments.md')

    courses = parse_timetable(timetable)

    for day_num, entries in WEEKEND_DEFAULTS.items():
        if day_num not in courses:
            courses[day_num] = []
        existing_times = {e['t'] for e in courses.get(day_num, [])}
        for entry in entries:
            if entry['t'] not in existing_times:
                courses[day_num].append(entry)

    assignments = parse_assignments(ass_text)
    stats = calc_stats(courses, assignments)

    time_order = {t: i for i, t in enumerate(TIME_SLOTS)}
    for day_num in courses:
        courses[day_num].sort(key=lambda x: time_order.get(x['t'], 99))

    pending_assignments = [a for a in assignments if not a.get('done')]
    output = {
        'courses': dict(sorted(courses.items(), key=lambda x: int(x[0]))),
        'assignments': pending_assignments,
        'stats': stats,
        'weekRange': '当前学期',
    }

    js_lines = [
        '// 自动生成 — 读 data/*.md 后同步',
        '// 数据源：data/timetable.md + data/assignments.md',
        '// 时间槽：第1节(08:00-09:35) 第2节(09:50-12:15) 第3节(13:30-15:05)',
        '//         第4节(15:20-16:55) 第5节(17:05-18:40) 第6节(19:20-21:45)',
        'var SCHEDULE_DATA = ' + json.dumps(output, ensure_ascii=False, indent=2) + ';',
        '',
    ]
    write('data.js', '\n'.join(js_lines))

    class_count = len([c for day in courses.values() for c in day if c['type'] == 'class'])
    print(f'✅ data/data.js 已更新')
    print(f'   - 课程数: {class_count}')
    print(f'   - 待办数: {stats["pendingCount"]}')
    print(f'   - 自由时段: {stats["freeHours"]}h')
    print(f'   - 健身: {stats["fitnessDays"]}次/周')


if __name__ == '__main__':
    gen()
